# Sistema de Rotas Aéreas — PRJ.ED.10 e PRJ.ED.11

Projeto em **TypeScript** + **PostgreSQL/PostGIS** que implementa busca de rotas aéreas utilizando:

- **PRJ.ED.10** → Algoritmo de **Dijkstra** (menor distância em km)
- **PRJ.ED.11** → Algoritmo de **BFS** (menor número de escalas)

---

## Estrutura do projeto

```
airline-routes/
├── docker-compose.yml        # PostgreSQL + PostGIS
├── init.sql                  # Schema, aeroportos e rotas reais
├── tsconfig.json
├── package.json
└── src/
    ├── types.ts              # Interfaces compartilhadas
    ├── database.ts           # Conexão e queries PostGIS
    ├── graph.ts              # Estrutura de grafo (mapa de adjacência)
    ├── minHeap.ts            # Min-heap para o Dijkstra
    ├── dijkstra.ts           # PRJ.ED.10
    ├── bfs.ts                # PRJ.ED.11
    └── main.ts               # Ponto de entrada (CLI interativo)
```

---

## Pré-requisitos

- [Node.js](https://nodejs.org/) >= 18
- [Docker](https://www.docker.com/) + Docker Compose

---

## Como rodar

### 1. Subir o banco PostGIS

```bash
docker-compose up -d
```

Aguarde ~10 segundos para o banco inicializar e rodar o `init.sql`.

### 2. Instalar dependências

```bash
npm install
```

### 3. Executar o sistema

```bash
npm run dev
```

---

## Exemplo de uso

```
  Menu:
  [1] Buscar rota (Dijkstra + BFS)
  [2] Ver grafo completo
  [3] Cadastrar nova rota
  [4] Cadastrar novo aeroporto
  [0] Sair

  Opção: 1
  Aeroporto de origem  (ex: GRU): GRU
  Aeroporto de destino (ex: FOR): FOR

─── PRJ.ED.10 — Dijkstra  (menor distância) ──
  Rota    : GRU → FOR
  Escalas : voo direto (sem escalas)
  Distância total: 2674 km

─── PRJ.ED.11 — BFS       (menor nº de escalas) ──
  Rota    : GRU → FOR
  Escalas : voo direto (sem escalas)
  Distância total: 2674 km
```

---

## Diferença entre os algoritmos

| | Dijkstra (ED.10) | BFS (ED.11) |
|---|---|---|
| **Otimiza** | Menor distância (km) | Menor nº de escalas |
| **Estrutura** | Min-heap (fila de prioridade) | Fila FIFO (deque) |
| **Peso das arestas** | Distância em km (PostGIS) | Todas valem 1 (hop) |
| **Garante** | Caminho mais curto em peso | Caminho com menos saltos |
| **Complexidade** | O((V + E) log V) | O(V + E) |

---

## Variáveis de ambiente (opcional)

Crie um `.env` na raiz para sobrescrever os defaults:

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=airline
DB_USER=admin
DB_PASSWORD=admin
```
