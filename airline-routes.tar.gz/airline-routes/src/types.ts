// src/types.ts

export interface Airport {
  code: string;
  name: string;
  city: string;
}

export interface RouteEdge {
  origin: string;
  destination: string;
  distanceKm: number;
}

// Resultado da busca — mesma estrutura para Dijkstra e BFS
export interface SearchResult {
  path: string[];          // ex: ['GRU', 'BSB', 'FOR']
  stops: number;           // nº de escalas (aeroportos intermediários)
  totalDistanceKm: number; // distância acumulada em km
  algorithm: 'dijkstra' | 'bfs';
}
