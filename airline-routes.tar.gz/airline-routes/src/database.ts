// src/database.ts
import { Pool, PoolClient } from 'pg';
import { Airport, RouteEdge } from './types';

// ── Configuração da conexão ─────────────────────────────────────────────────
const pool = new Pool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     Number(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME     || 'airline',
  user:     process.env.DB_USER     || 'admin',
  password: process.env.DB_PASSWORD || 'admin',
});

// ── Helpers ─────────────────────────────────────────────────────────────────

export async function getClient(): Promise<PoolClient> {
  return pool.connect();
}

export async function closePool(): Promise<void> {
  await pool.end();
}

// ── Aeroportos ───────────────────────────────────────────────────────────────

export async function loadAirports(): Promise<Airport[]> {
  const client = await pool.connect();
  try {
    const result = await client.query<Airport>(`
      SELECT code, name, city
      FROM airports
      ORDER BY code
    `);
    return result.rows;
  } finally {
    client.release();
  }
}

// ── Rotas com distância calculada pelo PostGIS ────────────────────────────────

export async function loadRoutes(): Promise<RouteEdge[]> {
  const client = await pool.connect();
  try {
    /*
     * A view `routes_with_distance` já faz o JOIN e chama ST_Distance
     * para calcular o custo em km — núcleo do uso de PostGIS.
     */
    const result = await client.query<{
      origin_code:      string;
      destination_code: string;
      distance_km:      string; // numeric vem como string no driver pg
    }>(`
      SELECT origin_code, destination_code, distance_km
      FROM routes_with_distance
      ORDER BY origin_code, destination_code
    `);

    return result.rows.map(row => ({
      origin:      row.origin_code,
      destination: row.destination_code,
      distanceKm:  parseFloat(row.distance_km),
    }));
  } finally {
    client.release();
  }
}

// ── Cadastro de nova rota ────────────────────────────────────────────────────

export async function insertRoute(
  originCode: string,
  destinationCode: string,
): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(
      `INSERT INTO routes (origin_code, destination_code)
       VALUES ($1, $2)
       ON CONFLICT DO NOTHING`,
      [originCode, destinationCode],
    );
    console.log(`  ✔ Rota ${originCode} → ${destinationCode} cadastrada.`);
  } finally {
    client.release();
  }
}

// ── Cadastro de novo aeroporto ───────────────────────────────────────────────

export async function insertAirport(
  code: string,
  name: string,
  city: string,
  longitude: number,
  latitude: number,
): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query(
      `INSERT INTO airports (code, name, city, location)
       VALUES ($1, $2, $3, ST_GeogFromText('POINT(' || $4 || ' ' || $5 || ')'))
       ON CONFLICT DO NOTHING`,
      [code, name, city, longitude, latitude],
    );
    console.log(`  ✔ Aeroporto ${code} (${city}) cadastrado.`);
  } finally {
    client.release();
  }
}
