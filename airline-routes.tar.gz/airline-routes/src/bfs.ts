// src/bfs.ts
// PRJ.ED.11 — Busca pelo caminho com MENOR NÚMERO DE ESCALAS

import { AirlineGraph } from './graph';
import { SearchResult } from './types';

// Estado interno da fila BFS
interface BfsNode {
  code:           string;
  path:           string[];
  totalDistanceKm: number;
}

/**
 * Algoritmo de Busca em Largura (BFS) para rotas aéreas.
 *
 * A BFS explora nível por nível (hop a hop), garantindo que o PRIMEIRO
 * caminho a chegar ao destino seja o que possui MENOS ARESTAS, ou seja,
 * o menor número de escalas — independentemente da distância total.
 *
 * Todas as arestas têm "peso 1" do ponto de vista da BFS.
 * A distância acumulada é registrada apenas como informação adicional.
 *
 * Complexidade: O(V + E)
 *
 * @param graph       Grafo de adjacência carregado do PostGIS
 * @param origin      Código IATA do aeroporto de origem
 * @param destination Código IATA do aeroporto de destino
 * @returns SearchResult com o caminho e número de escalas, ou null se não houver rota
 */
export function bfs(
  graph:       AirlineGraph,
  origin:      string,
  destination: string,
): SearchResult | null {

  if (!graph.hasNode(origin)) {
    throw new Error(`Aeroporto de origem não encontrado: ${origin}`);
  }

  // Fila FIFO: garante expansão nível a nível (1 escala, 2 escalas, ...)
  const queue: BfsNode[] = [
    { code: origin, path: [origin], totalDistanceKm: 0 },
  ];

  // Visitados: evita ciclos e re-expansão
  const visited = new Set<string>([origin]);

  while (queue.length > 0) {
    // Retira o primeiro da fila (FIFO — essência da BFS)
    const { code, path, totalDistanceKm } = queue.shift()!;

    // Chegamos ao destino com o menor número de escalas garantido pela BFS
    if (code === destination) {
      return {
        path,
        stops:           path.length - 2, // nós intermediários = escalas
        totalDistanceKm,
        algorithm:       'bfs',
      };
    }

    // Expande vizinhos não visitados — sem prioridade de custo
    for (const neighbor of graph.neighbors(code)) {
      if (!visited.has(neighbor.code)) {
        visited.add(neighbor.code);
        queue.push({
          code:            neighbor.code,
          path:            [...path, neighbor.code],
          totalDistanceKm: totalDistanceKm + neighbor.distanceKm,
        });
      }
    }
  }

  // Nenhum caminho encontrado
  return null;
}
