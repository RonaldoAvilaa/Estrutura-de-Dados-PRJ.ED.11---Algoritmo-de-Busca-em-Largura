// src/main.ts
import * as readline from 'readline';
import { loadAirports, loadRoutes, closePool, insertRoute, insertAirport } from './database';
import { AirlineGraph } from './graph';
import { dijkstra }     from './dijkstra';
import { bfs }          from './bfs';
import { SearchResult } from './types';

// ── Utilitários de exibição ──────────────────────────────────────────────────

function printBanner(): void {
  console.log('\n╔══════════════════════════════════════════════╗');
  console.log(  '║    Sistema de Rotas Aéreas — PRJ.ED.10/11   ║');
  console.log(  '╚══════════════════════════════════════════════╝\n');
}

function printResult(result: SearchResult | null, label: string): void {
  console.log(`\n─── ${label} ──────────────────────────────`);

  if (!result) {
    console.log('  ✗ Nenhuma rota encontrada entre esses aeroportos.');
    return;
  }

  const arrow = result.path.join(' → ');
  const stops = result.stops <= 0
    ? 'voo direto (sem escalas)'
    : `${result.stops} escala(s)`;

  console.log(`  Rota    : ${arrow}`);
  console.log(`  Escalas : ${stops}`);
  console.log(`  Distância total: ${result.totalDistanceKm.toFixed(0)} km`);
}

function printComparison(
  dijkstraResult: SearchResult | null,
  bfsResult:      SearchResult | null,
): void {
  console.log('\n═══ Comparação ═══════════════════════════════');

  if (!dijkstraResult && !bfsResult) {
    console.log('  Nenhum algoritmo encontrou rota.');
    return;
  }

  if (dijkstraResult && bfsResult) {
    if (dijkstraResult.path.join() === bfsResult.path.join()) {
      console.log('  ✔ Ambos encontraram a mesma rota!');
    } else {
      const savedKm = Math.abs(
        bfsResult.totalDistanceKm - dijkstraResult.totalDistanceKm,
      ).toFixed(0);
      const savedStops = Math.abs(bfsResult.stops - dijkstraResult.stops);

      console.log(`  Dijkstra economiza ${savedKm} km a mais.`);
      if (savedStops > 0) {
        console.log(`  BFS economiza ${savedStops} escala(s) a mais.`);
      }
    }
  }
}

// ── Interface interativa via readline ────────────────────────────────────────

function prompt(rl: readline.Interface, question: string): Promise<string> {
  return new Promise(resolve => rl.question(question, resolve));
}

async function runSearch(
  graph:  AirlineGraph,
  rl:     readline.Interface,
): Promise<void> {
  const origin      = (await prompt(rl, '  Aeroporto de origem  (ex: GRU): ')).toUpperCase().trim();
  const destination = (await prompt(rl, '  Aeroporto de destino (ex: FOR): ')).toUpperCase().trim();

  if (!graph.hasNode(origin)) {
    console.log(`  ✗ Aeroporto "${origin}" não encontrado no grafo.`);
    return;
  }

  console.log(`\n  Buscando rotas de ${origin} para ${destination}...\n`);

  // PRJ.ED.10 — Dijkstra
  const dijkstraResult = dijkstra(graph, origin, destination);
  printResult(dijkstraResult, 'PRJ.ED.10 — Dijkstra  (menor distância)');

  // PRJ.ED.11 — BFS
  const bfsResult = bfs(graph, origin, destination);
  printResult(bfsResult, 'PRJ.ED.11 — BFS       (menor nº de escalas)');

  printComparison(dijkstraResult, bfsResult);
}

async function runAddRoute(
  rl: readline.Interface,
): Promise<void> {
  const origin      = (await prompt(rl, '  Código de origem  (ex: GRU): ')).toUpperCase().trim();
  const destination = (await prompt(rl, '  Código de destino (ex: FOR): ')).toUpperCase().trim();
  await insertRoute(origin, destination);
}

async function runAddAirport(
  rl: readline.Interface,
): Promise<void> {
  const code      = (await prompt(rl, '  Código IATA (3 letras): ')).toUpperCase().trim();
  const name      = await prompt(rl, '  Nome do aeroporto: ');
  const city      = await prompt(rl, '  Cidade: ');
  const longitude = parseFloat(await prompt(rl, '  Longitude (ex: -46.4731): '));
  const latitude  = parseFloat(await prompt(rl, '  Latitude  (ex: -23.4356): '));
  await insertAirport(code, name, city, longitude, latitude);
}

// ── Ponto de entrada ─────────────────────────────────────────────────────────

async function main(): Promise<void> {
  printBanner();

  console.log('  Conectando ao banco PostGIS e carregando grafo...');
  const [airports, edges] = await Promise.all([loadAirports(), loadRoutes()]);
  const graph = new AirlineGraph(edges);

  console.log(`  ✔ ${airports.length} aeroportos | ${edges.length} rotas carregadas.\n`);

  const rl = readline.createInterface({
    input:  process.stdin,
    output: process.stdout,
  });

  let running = true;

  while (running) {
    console.log('\n  Menu:');
    console.log('  [1] Buscar rota (Dijkstra + BFS)');
    console.log('  [2] Ver grafo completo');
    console.log('  [3] Cadastrar nova rota');
    console.log('  [4] Cadastrar novo aeroporto');
    console.log('  [0] Sair');

    const option = (await prompt(rl, '\n  Opção: ')).trim();

    switch (option) {
      case '1':
        await runSearch(graph, rl);
        break;
      case '2':
        graph.print();
        break;
      case '3':
        await runAddRoute(rl);
        // Recarrega grafo com a nova rota
        {
          const newEdges = await loadRoutes();
          Object.assign(graph, new AirlineGraph(newEdges));
        }
        break;
      case '4':
        await runAddAirport(rl);
        break;
      case '0':
        running = false;
        break;
      default:
        console.log('  Opção inválida.');
    }
  }

  rl.close();
  await closePool();
  console.log('\n  Encerrando. Até logo!\n');
}

main().catch(err => {
  console.error('Erro fatal:', err);
  process.exit(1);
});
