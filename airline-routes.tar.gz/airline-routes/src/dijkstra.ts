// src/dijkstra.ts
// PRJ.ED.10 — Busca pelo caminho de MENOR DISTÂNCIA (custo em km)

import { AirlineGraph } from './graph';
import { MinHeap }      from './minHeap';
import { SearchResult } from './types';

/**
 * Algoritmo de Dijkstra adaptado para o grafo de rotas aéreas.
 *
 * Garante o caminho com MENOR CUSTO TOTAL (distância em km).
 * Utiliza uma min-heap para sempre expandir o nó de menor custo acumulado.
 *
 * Complexidade: O((V + E) log V)
 *
 * @param graph     Grafo de adjacência carregado do PostGIS
 * @param origin    Código IATA do aeroporto de origem
 * @param destination Código IATA do aeroporto de destino
 * @returns SearchResult com o caminho e custo, ou null se não houver rota
 */
export function dijkstra(
  graph:       AirlineGraph,
  origin:      string,
  destination: string,
): SearchResult | null {

  // Valida se os nós existem no grafo
  if (!graph.hasNode(origin)) {
    throw new Error(`Aeroporto de origem não encontrado: ${origin}`);
  }

  // Heap mínima: ordena pelo custo acumulado (menor distância primeiro)
  const heap    = new MinHeap();
  const visited = new Set<string>();

  // Estado inicial: custo 0, no aeroporto de origem
  heap.push({ cost: 0, code: origin, path: [origin] });

  while (!heap.isEmpty()) {
    const { cost, code, path } = heap.pop();

    // Nó já processado com custo menor → ignora
    if (visited.has(code)) continue;
    visited.add(code);

    // Chegamos ao destino!
    if (code === destination) {
      return {
        path,
        stops:          path.length - 2,  // descontando origem e destino
        totalDistanceKm: cost,
        algorithm:      'dijkstra',
      };
    }

    // Expande vizinhos: empurra na heap com custo acumulado
    for (const neighbor of graph.neighbors(code)) {
      if (!visited.has(neighbor.code)) {
        heap.push({
          cost: cost + neighbor.distanceKm,
          code: neighbor.code,
          path: [...path, neighbor.code],
        });
      }
    }
  }

  // Nenhum caminho encontrado
  return null;
}
