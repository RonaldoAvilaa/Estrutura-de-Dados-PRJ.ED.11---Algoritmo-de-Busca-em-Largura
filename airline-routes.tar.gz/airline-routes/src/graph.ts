// src/graph.ts
import { RouteEdge } from './types';

// Cada entrada do mapa de adjacência: destino + custo em km
export interface Neighbor {
  code:       string;
  distanceKm: number;
}

export class AirlineGraph {
  // Mapa de adjacência: { 'GRU': [{ code: 'GIG', distanceKm: 357 }, ...] }
  private adjacency: Map<string, Neighbor[]> = new Map();

  constructor(edges: RouteEdge[]) {
    this.build(edges);
  }

  private build(edges: RouteEdge[]): void {
    for (const edge of edges) {
      if (!this.adjacency.has(edge.origin)) {
        this.adjacency.set(edge.origin, []);
      }
      this.adjacency.get(edge.origin)!.push({
        code:       edge.destination,
        distanceKm: edge.distanceKm,
      });
    }
  }

  neighbors(node: string): Neighbor[] {
    return this.adjacency.get(node) ?? [];
  }

  hasNode(node: string): boolean {
    return this.adjacency.has(node);
  }

  allNodes(): string[] {
    return Array.from(this.adjacency.keys());
  }

  // Exibe o grafo no console (útil para debug)
  print(): void {
    console.log('\n=== Grafo de rotas ===');
    for (const [origin, neighbors] of this.adjacency) {
      const list = neighbors
        .map(n => `${n.code}(${n.distanceKm.toFixed(0)} km)`)
        .join(', ');
      console.log(`  ${origin} → ${list}`);
    }
    console.log('');
  }
}
