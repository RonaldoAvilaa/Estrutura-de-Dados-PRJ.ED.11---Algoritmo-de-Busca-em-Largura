-- Habilita extensão PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- Tabela de aeroportos com localização geográfica (PostGIS)
CREATE TABLE IF NOT EXISTS airports (
    id     SERIAL PRIMARY KEY,
    code   VARCHAR(3)   UNIQUE NOT NULL,
    name   VARCHAR(100) NOT NULL,
    city   VARCHAR(100) NOT NULL,
    location GEOGRAPHY(POINT, 4326) NOT NULL  -- coordenadas WGS84
);

-- Tabela de rotas entre aeroportos
CREATE TABLE IF NOT EXISTS routes (
    id               SERIAL PRIMARY KEY,
    origin_code      VARCHAR(3) NOT NULL REFERENCES airports(code),
    destination_code VARCHAR(3) NOT NULL REFERENCES airports(code),
    UNIQUE (origin_code, destination_code)
);

-- View que calcula a distância automaticamente via PostGIS
CREATE OR REPLACE VIEW routes_with_distance AS
SELECT
    r.id,
    r.origin_code,
    r.destination_code,
    a1.name        AS origin_name,
    a2.name        AS destination_name,
    ROUND(
        (ST_Distance(a1.location, a2.location) / 1000)::numeric, 2
    )              AS distance_km
FROM routes r
JOIN airports a1 ON r.origin_code      = a1.code
JOIN airports a2 ON r.destination_code = a2.code;

-- ============================================================
-- Aeroportos reais brasileiros
-- ============================================================
INSERT INTO airports (code, name, city, location) VALUES
('GRU', 'Aeroporto Internacional de Guarulhos',     'São Paulo',      ST_GeogFromText('POINT(-46.4731 -23.4356)')),
('GIG', 'Aeroporto Internacional do Galeão',        'Rio de Janeiro', ST_GeogFromText('POINT(-43.2436 -22.8099)')),
('BSB', 'Aeroporto Internacional de Brasília',      'Brasília',       ST_GeogFromText('POINT(-47.9139 -15.8711)')),
('SSA', 'Aeroporto Internacional de Salvador',      'Salvador',       ST_GeogFromText('POINT(-38.3324 -12.9086)')),
('FOR', 'Aeroporto Internacional de Fortaleza',     'Fortaleza',      ST_GeogFromText('POINT(-38.5326 -3.7762)')),
('REC', 'Aeroporto Internacional do Recife',        'Recife',         ST_GeogFromText('POINT(-34.9237 -8.1264)')),
('MAO', 'Aeroporto Internacional de Manaus',        'Manaus',         ST_GeogFromText('POINT(-60.0491 -3.0386)')),
('CWB', 'Aeroporto Internacional de Curitiba',      'Curitiba',       ST_GeogFromText('POINT(-49.1753 -25.5285)')),
('POA', 'Aeroporto Internacional de Porto Alegre',  'Porto Alegre',   ST_GeogFromText('POINT(-51.1714 -29.9939)')),
('BEL', 'Aeroporto Internacional de Belém',         'Belém',          ST_GeogFromText('POINT(-48.4792 -1.3792)')),
('MCZ', 'Aeroporto Internacional de Maceió',        'Maceió',         ST_GeogFromText('POINT(-35.7917 -9.5108)')),
('FLN', 'Aeroporto Internacional de Florianópolis', 'Florianópolis',  ST_GeogFromText('POINT(-48.5517 -27.6702)'))
ON CONFLICT DO NOTHING;

-- ============================================================
-- Rotas disponíveis (grafo direcionado)
-- ============================================================
INSERT INTO routes (origin_code, destination_code) VALUES
-- GRU (hub principal)
('GRU', 'GIG'), ('GRU', 'BSB'), ('GRU', 'CWB'), ('GRU', 'POA'),
('GRU', 'SSA'), ('GRU', 'FOR'), ('GRU', 'MAO'),
-- GIG
('GIG', 'GRU'), ('GIG', 'BSB'), ('GIG', 'SSA'), ('GIG', 'FLN'),
-- BSB (hub do centro-oeste)
('BSB', 'GRU'), ('BSB', 'GIG'), ('BSB', 'FOR'), ('BSB', 'MAO'),
('BSB', 'BEL'), ('BSB', 'SSA'),
-- Nordeste
('SSA', 'GIG'), ('SSA', 'REC'), ('SSA', 'FOR'), ('SSA', 'MCZ'),
('FOR', 'BSB'), ('FOR', 'SSA'), ('FOR', 'REC'), ('FOR', 'GRU'),
('REC', 'FOR'), ('REC', 'SSA'), ('REC', 'MCZ'),
('MCZ', 'REC'), ('MCZ', 'SSA'),
-- Norte
('MAO', 'BSB'), ('MAO', 'BEL'), ('MAO', 'GRU'),
('BEL', 'BSB'), ('BEL', 'MAO'),
-- Sul
('CWB', 'GRU'), ('CWB', 'POA'), ('CWB', 'FLN'),
('POA', 'GRU'), ('POA', 'CWB'), ('POA', 'FLN'),
('FLN', 'GIG'), ('FLN', 'CWB'), ('FLN', 'POA')
ON CONFLICT DO NOTHING;
